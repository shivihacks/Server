import os
import threading
import time
import uuid
from collections import deque
from pathlib import Path
from typing import Any, BinaryIO, Callable, Deque, Dict, List, Optional, Tuple

from config import CHUNK_SIZE, MAX_FILE_SIZE_BYTES, SPEED_WINDOW_SECONDS
from backend.database import DatabaseManager
from backend.security import SecurityManager


class TransferSession:
    """Tracks live state, rolling byte samples, cancellation flag, and temp/final paths."""

    def __init__(
        self,
        transfer_id: str,
        filename: str,
        file_size: int,
        sender_device: str,
        receiver_device: str,
        direction: str,
        temp_path: Path,
        target_dir: Path,
    ) -> None:
        self.transfer_id = transfer_id
        self.filename = filename
        self.file_size = int(file_size)
        self.sender_device = sender_device
        self.receiver_device = receiver_device
        self.direction = direction
        self.temp_path = temp_path
        self.target_dir = target_dir
        self.final_path: Optional[Path] = None

        now = time.time()
        self.created_at = now
        self.started_at: Optional[float] = None
        self.completed_at: Optional[float] = None

        # pending_approval | transferring | completed | failed | cancelled | rejected
        self.status = "pending_approval"
        self.transferred_bytes = 0
        self.error_message: Optional[str] = None
        self.cancel_event = threading.Event()
        self._samples: Deque[Tuple[float, int]] = deque()
        self._lock = threading.Lock()

    def record_bytes(self, byte_count: int) -> None:
        now = time.time()
        with self._lock:
            self.transferred_bytes += byte_count
            self._samples.append((now, byte_count))
            cutoff = now - SPEED_WINDOW_SECONDS
            while self._samples and self._samples[0][0] < cutoff:
                self._samples.popleft()

    def compute_metrics(self) -> Dict[str, Any]:
        now = time.time()
        with self._lock:
            transferred = self.transferred_bytes
            total = self.file_size
            percent = round(min(100.0, (transferred / total) * 100.0), 1) if total > 0 else (
                100.0 if self.status == "completed" else 0.0
            )

            # Rolling window speed
            cutoff = now - SPEED_WINDOW_SECONDS
            recent_bytes = sum(b for ts, b in self._samples if ts >= cutoff)
            elapsed_window = max(0.15, min(SPEED_WINDOW_SECONDS, now - (self._samples[0][0] if self._samples else now)))
            current_speed = (recent_bytes / elapsed_window) if self.status == "transferring" and recent_bytes > 0 else 0.0

            # Average speed across active duration
            start_ts = self.started_at or self.created_at
            end_ts = self.completed_at or now
            active_elapsed = max(0.1, end_ts - start_ts)
            avg_speed = (transferred / active_elapsed) if transferred > 0 else 0.0

            # Remaining time based on current speed with fallback to average speed
            remaining_bytes = max(0, total - transferred) if total > 0 else 0
            effective_speed = current_speed if current_speed > 1024 else avg_speed
            if self.status == "transferring" and total > 0 and effective_speed > 1.0:
                eta_seconds: Optional[float] = remaining_bytes / effective_speed
            elif self.status == "completed":
                eta_seconds = 0.0
            else:
                eta_seconds = None

            duration = round(active_elapsed, 2) if self.completed_at or self.status in ("failed", "cancelled") else round(max(0.0, now - start_ts), 2)

            return {
                "transfer_id": self.transfer_id,
                "filename": self.filename,
                "file_size": total,
                "transferred_bytes": transferred,
                "percent": percent,
                "speed_bps": round(current_speed, 1),
                "avg_speed_bps": round(avg_speed, 1),
                "eta_seconds": round(eta_seconds, 1) if eta_seconds is not None else None,
                "duration_seconds": duration,
                "status": self.status,
                "sender_device": self.sender_device,
                "receiver_device": self.receiver_device,
                "direction": self.direction,
                "error_message": self.error_message,
                "saved_as": self.final_path.name if self.final_path else None,
            }


class TransferManager:
    """Coordinates incoming transfer approvals, streaming chunk writes, progress, and history."""

    def __init__(self, db: DatabaseManager, received_dir: Path, temp_dir: Path) -> None:
        self.db = db
        self.received_dir = Path(received_dir)
        self.temp_dir = Path(temp_dir)
        self._lock = threading.Lock()
        self._sessions: Dict[str, TransferSession] = {}
        self._subscribers: List[Callable[[Dict[str, Any]], None]] = []

    def subscribe(self, callback: Callable[[Dict[str, Any]], None]) -> None:
        with self._lock:
            self._subscribers.append(callback)

    def _emit_event(self, payload: Dict[str, Any]) -> None:
        with self._lock:
            callbacks = list(self._subscribers)
        for cb in callbacks:
            try:
                cb(payload)
            except Exception:
                pass

    def _persist_history(self, session: TransferSession) -> None:
        metrics = session.compute_metrics()
        self.db.upsert_transfer(
            {
                "transfer_id": session.transfer_id,
                "filename": session.filename,
                "file_size": session.file_size,
                "sender_device": session.sender_device,
                "receiver_device": session.receiver_device,
                "direction": session.direction,
                "created_at": session.created_at,
                "completed_at": session.completed_at,
                "status": session.status,
                "duration_seconds": metrics["duration_seconds"],
                "avg_speed_bps": metrics["avg_speed_bps"],
                "error_message": session.error_message,
            }
        )

    def create_incoming_request(
        self,
        raw_filename: str,
        file_size: int,
        sender_device: str,
        receiver_device: str = "SHIVSHARE Host (Termux)",
        auto_accept: bool = False,
    ) -> Tuple[bool, str, Optional[Dict[str, Any]]]:
        """Validate size & disk space, create a transfer session awaiting user approval."""
        safe_name = SecurityManager.sanitize_filename(raw_filename)
        size_int = max(0, int(file_size or 0))

        if size_int > MAX_FILE_SIZE_BYTES:
            return False, "File exceeds maximum supported transfer size.", None

        try:
            statvfs = os.statvfs(self.temp_dir)
            free_space = statvfs.f_bavail * statvfs.f_frsize
            # Require at least size + 50 MB buffer
            if size_int > 0 and free_space < (size_int + 50 * 1024 * 1024):
                return False, "Insufficient free storage space on device.", None
        except OSError:
            pass

        transfer_id = f"tr_{uuid.uuid4().hex[:12]}"
        temp_file = self.temp_dir / f"{transfer_id}.part"

        session = TransferSession(
            transfer_id=transfer_id,
            filename=safe_name,
            file_size=size_int,
            sender_device=sender_device,
            receiver_device=receiver_device,
            direction="upload",
            temp_path=temp_file,
            target_dir=self.received_dir,
        )
        if auto_accept:
            session.status = "transferring"
            session.started_at = time.time()

        with self._lock:
            self._sessions[transfer_id] = session

        self._persist_history(session)
        metrics = session.compute_metrics()
        self._emit_event({"type": "transfer_update", "transfer": metrics})
        return True, "Transfer request registered.", metrics

    def decide_transfer(self, transfer_id: str, accept: bool) -> Tuple[bool, str, Optional[Dict[str, Any]]]:
        """Approve or reject an incoming transfer."""
        with self._lock:
            session = self._sessions.get(transfer_id)
            if not session:
                return False, "Transfer session not found.", None
            if session.status not in ("pending_approval", "transferring"):
                return False, f"Transfer is already {session.status}.", session.compute_metrics()

            if accept:
                session.status = "transferring"
                if not session.started_at:
                    session.started_at = time.time()
                msg = "Transfer accepted."
            else:
                session.status = "rejected"
                session.completed_at = time.time()
                session.cancel_event.set()
                msg = "Transfer rejected."

        self._cleanup_temp(session.temp_path)
        self._persist_history(session)
        metrics = session.compute_metrics()
        self._emit_event({"type": "transfer_update", "transfer": metrics})
        return True, msg, metrics

    def stream_into_session(
        self,
        transfer_id: str,
        stream: BinaryIO,
        expected_size: int = 0,
    ) -> Tuple[bool, str, Optional[Dict[str, Any]]]:
        """Stream incoming binary chunks to disk without buffering the entire file in RAM."""
        with self._lock:
            session = self._sessions.get(transfer_id)
            if not session:
                return False, "Transfer not found.", None

        # Wait briefly if user is approving right as upload starts
        wait_deadline = time.time() + 120.0
        while True:
            if session.cancel_event.is_set() or session.status in ("rejected", "cancelled"):
                self._cleanup_temp(session.temp_path)
                self._persist_history(session)
                return False, "Transfer was rejected or cancelled.", session.compute_metrics()
            if session.status == "transferring":
                break
            if time.time() > wait_deadline:
                session.status = "failed"
                session.completed_at = time.time()
                session.error_message = "Timed out waiting for receiver approval."
                self._cleanup_temp(session.temp_path)
                self._persist_history(session)
                return False, session.error_message, session.compute_metrics()
            time.sleep(0.15)

        if not session.started_at:
            session.started_at = time.time()

        if expected_size > 0 and session.file_size <= 0:
            session.file_size = int(expected_size)

        last_emit = 0.0
        try:
            with open(session.temp_path, "wb") as out_f:
                while True:
                    if session.cancel_event.is_set():
                        session.status = "cancelled"
                        session.completed_at = time.time()
                        session.error_message = "Transfer cancelled."
                        break

                    chunk = stream.read(CHUNK_SIZE)
                    if not chunk:
                        break

                    out_f.write(chunk)
                    session.record_bytes(len(chunk))

                    now = time.time()
                    if now - last_emit >= 0.25:
                        last_emit = now
                        self._emit_event({"type": "transfer_update", "transfer": session.compute_metrics()})

            if session.status == "cancelled":
                self._cleanup_temp(session.temp_path)
                self._persist_history(session)
                metrics = session.compute_metrics()
                self._emit_event({"type": "transfer_update", "transfer": metrics})
                return False, "Transfer cancelled.", metrics

            # Commit completed temp file to non-overwriting destination path
            final_path = SecurityManager.allocate_non_overwriting_path(session.target_dir, session.filename)
            os.replace(session.temp_path, final_path)
            session.final_path = final_path
            if session.file_size == 0:
                session.file_size = session.transferred_bytes
            session.status = "completed"
            session.completed_at = time.time()
            self._persist_history(session)
            metrics = session.compute_metrics()
            self._emit_event({"type": "transfer_update", "transfer": metrics})
            return True, f"Saved as {final_path.name}", metrics

        except Exception as exc:
            session.status = "failed"
            session.completed_at = time.time()
            session.error_message = f"Transfer interrupted: {exc}"
            self._cleanup_temp(session.temp_path)
            self._persist_history(session)
            metrics = session.compute_metrics()
            self._emit_event({"type": "transfer_update", "transfer": metrics})
            return False, session.error_message, metrics

    def cancel_transfer(self, transfer_id: str) -> Tuple[bool, str, Optional[Dict[str, Any]]]:
        with self._lock:
            session = self._sessions.get(transfer_id)
            if not session:
                return False, "Transfer not found.", None
            if session.status in ("completed", "failed", "cancelled", "rejected"):
                return True, f"Transfer already {session.status}.", session.compute_metrics()
            session.cancel_event.set()
            session.status = "cancelled"
            session.completed_at = time.time()
            session.error_message = "Cancelled by user."

        self._cleanup_temp(session.temp_path)
        self._persist_history(session)
        metrics = session.compute_metrics()
        self._emit_event({"type": "transfer_update", "transfer": metrics})
        return True, "Transfer cancelled.", metrics

    def record_download_completed(
        self,
        filename: str,
        file_size: int,
        sender_device: str,
        receiver_device: str,
        duration_seconds: float,
    ) -> Dict[str, Any]:
        transfer_id = f"dl_{uuid.uuid4().hex[:12]}"
        now = time.time()
        avg_speed = (file_size / max(0.1, duration_seconds)) if file_size > 0 else 0.0
        record = {
            "transfer_id": transfer_id,
            "filename": SecurityManager.sanitize_filename(filename),
            "file_size": int(file_size),
            "sender_device": sender_device,
            "receiver_device": receiver_device,
            "direction": "download",
            "created_at": now - max(0.0, duration_seconds),
            "completed_at": now,
            "status": "completed",
            "duration_seconds": round(max(0.0, duration_seconds), 2),
            "avg_speed_bps": round(avg_speed, 1),
            "error_message": None,
        }
        self.db.upsert_transfer(record)
        self._emit_event({"type": "transfer_update", "transfer": record})
        return record

    def get_active_and_recent(self) -> List[Dict[str, Any]]:
        with self._lock:
            sessions = list(self._sessions.values())
        sessions.sort(key=lambda s: s.created_at, reverse=True)
        return [s.compute_metrics() for s in sessions[:50]]

    def get_session_metrics(self, transfer_id: str) -> Optional[Dict[str, Any]]:
        with self._lock:
            session = self._sessions.get(transfer_id)
            return session.compute_metrics() if session else None

    @staticmethod
    def _cleanup_temp(temp_path: Path) -> None:
        try:
            if temp_path.exists():
                temp_path.unlink()
        except OSError:
            pass