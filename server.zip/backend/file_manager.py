import mimetypes
import os
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from config import ANDROID_SHARED_CANDIDATES, FILE_CATEGORIES
from backend.security import SecurityManager


def categorize_file(filename: str) -> str:
    ext = Path(filename).suffix.lower()
    for category, extensions in FILE_CATEGORIES.items():
        if ext in extensions:
            return category
    return "other"


class FileManager:
    """Manages authorized/shared folders and received files without exposing private Android paths."""

    def __init__(self, received_dir: Path, temp_dir: Path) -> None:
        self.received_dir = Path(received_dir).resolve()
        self.temp_dir = Path(temp_dir).resolve()
        self.received_dir.mkdir(parents=True, exist_ok=True)
        self.temp_dir.mkdir(parents=True, exist_ok=True)
        self.authorized_roots: Dict[str, Path] = {
            "received": self.received_dir,
        }
        self.refresh_authorized_roots()

    def refresh_authorized_roots(self) -> Dict[str, Dict[str, Any]]:
        """Discover accessible Android/Termux shared folders that exist and are readable."""
        roots: Dict[str, Path] = {"received": self.received_dir}
        seen_resolved = {self.received_dir}

        for idx, candidate in enumerate(ANDROID_SHARED_CANDIDATES):
            try:
                if candidate.exists() and candidate.is_dir():
                    resolved = candidate.resolve()
                    if resolved not in seen_resolved and os.access(resolved, os.R_OK):
                        seen_resolved.add(resolved)
                        label = candidate.name or f"Shared_{idx}"
                        key = f"shared_{label.lower()}"
                        roots[key] = resolved
            except OSError:
                continue

        self.authorized_roots = roots
        return self.get_roots_info()

    def get_roots_info(self) -> Dict[str, Dict[str, Any]]:
        info: Dict[str, Dict[str, Any]] = {}
        for key, path in self.authorized_roots.items():
            info[key] = {
                "id": key,
                "label": "Received Files" if key == "received" else path.name,
                "path": str(path),
                "readable": os.access(path, os.R_OK),
                "writable": os.access(path, os.W_OK),
            }
        return info

    def check_storage_permissions(self) -> Dict[str, Any]:
        """Verify local storage and optional Android shared storage accessibility."""
        received_writable = os.access(self.received_dir, os.W_OK) and os.access(self.received_dir, os.R_OK)
        temp_writable = os.access(self.temp_dir, os.W_OK) and os.access(self.temp_dir, os.R_OK)
        termux_storage_link = Path.home() / "storage" / "shared"
        shared_accessible = termux_storage_link.exists() and os.access(termux_storage_link, os.R_OK)

        stat_target = self.received_dir
        try:
            usage = os.statvfs(stat_target)
            free_bytes = usage.f_bavail * usage.f_frsize
            total_bytes = usage.f_blocks * usage.f_frsize
        except OSError:
            free_bytes = 0
            total_bytes = 0

        return {
            "app_storage_ok": received_writable and temp_writable,
            "received_dir": str(self.received_dir),
            "shared_storage_linked": shared_accessible,
            "free_bytes": free_bytes,
            "total_bytes": total_bytes,
            "available_roots": len(self.authorized_roots),
        }

    def resolve_safe_path(self, root_id: str, rel_path: str = "") -> Optional[Tuple[Path, Path]]:
        """Resolve a relative path inside an authorized root safely."""
        root = self.authorized_roots.get(root_id or "received")
        if not root:
            return None

        cleaned_rel = (rel_path or "").lstrip("/\\")
        target = (root / cleaned_rel).resolve()
        if not SecurityManager.is_safe_subpath(root, target):
            return None
        return root, target

    def list_items(
        self,
        root_id: str = "received",
        subpath: str = "",
        category: str = "all",
        search: str = "",
        sort_by: str = "name",
        sort_order: str = "asc",
    ) -> Dict[str, Any]:
        """List folders and files inside an authorized root with filtering and sorting."""
        resolved_pair = self.resolve_safe_path(root_id, subpath)
        if not resolved_pair:
            return {
                "root_id": root_id,
                "subpath": "",
                "error": "Unauthorized or invalid directory.",
                "folders": [],
                "files": [],
                "counts": {},
            }

        root, current_dir = resolved_pair
        if not current_dir.exists() or not current_dir.is_dir():
            current_dir = root

        rel_current = "" if current_dir == root else str(current_dir.relative_to(root)).replace("\\", "/")

        folders: List[Dict[str, Any]] = []
        files: List[Dict[str, Any]] = []
        counts: Dict[str, int] = {
            "all": 0,
            "images": 0,
            "videos": 0,
            "audio": 0,
            "documents": 0,
            "apk": 0,
            "zip": 0,
            "other": 0,
        }

        search_lower = (search or "").strip().lower()
        cat_filter = (category or "all").strip().lower()

        try:
            entries = list(os.scandir(current_dir))
        except OSError as exc:
            return {
                "root_id": root_id,
                "subpath": rel_current,
                "error": f"Unable to read directory: {exc}",
                "folders": [],
                "files": [],
                "counts": counts,
            }

        for entry in entries:
            try:
                if entry.name.startswith("."):
                    continue
                stat = entry.stat(follow_symlinks=False)
                entry_rel = entry.name if not rel_current else f"{rel_current}/{entry.name}"

                if entry.is_dir(follow_symlinks=False):
                    if search_lower and search_lower not in entry.name.lower():
                        continue
                    folders.append(
                        {
                            "name": entry.name,
                            "rel_path": entry_rel,
                            "type": "folder",
                            "size": 0,
                            "modified_ts": stat.st_mtime,
                            "modified_str": datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M"),
                        }
                    )
                elif entry.is_file(follow_symlinks=False):
                    file_cat = categorize_file(entry.name)
                    counts["all"] += 1
                    counts[file_cat] = counts.get(file_cat, 0) + 1

                    if cat_filter != "all" and file_cat != cat_filter:
                        continue
                    if search_lower and search_lower not in entry.name.lower():
                        continue

                    mime_type, _ = mimetypes.guess_type(entry.name)
                    files.append(
                        {
                            "name": entry.name,
                            "rel_path": entry_rel,
                            "root_id": root_id,
                            "type": "file",
                            "category": file_cat,
                            "mime_type": mime_type or "application/octet-stream",
                            "size": stat.st_size,
                            "modified_ts": stat.st_mtime,
                            "modified_str": datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M"),
                        }
                    )
            except OSError:
                continue

        reverse = (sort_order or "asc").lower() == "desc"
        if sort_by == "size":
            key_fn = lambda item: int(item.get("size", 0))
        elif sort_by == "date":
            key_fn = lambda item: float(item.get("modified_ts", 0.0))
        else:
            key_fn = lambda item: str(item.get("name", "")).lower()

        folders.sort(key=key_fn, reverse=reverse)
        files.sort(key=key_fn, reverse=reverse)

        return {
            "root_id": root_id,
            "subpath": rel_current,
            "roots": self.get_roots_info(),
            "folders": folders,
            "files": files,
            "counts": counts,
        }

    def delete_received_file(self, rel_path: str) -> Tuple[bool, str]:
        """Delete only files inside the managed received directory."""
        resolved = self.resolve_safe_path("received", rel_path)
        if not resolved:
            return False, "Invalid file path."
        _, target = resolved
        if not target.exists() or not target.is_file():
            return False, "File not found in received folder."
        try:
            target.unlink()
            return True, "File removed."
        except OSError as exc:
            return False, f"Failed to delete file: {exc}"