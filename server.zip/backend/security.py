import hmac
import os
import re
import secrets
import threading
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple


class RateLimiter:
    """Sliding-window rate limiter per client IP."""

    def __init__(self, max_requests: int = 240, window_seconds: int = 60) -> None:
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        self._buckets: Dict[str, List[float]] = {}
        self._lock = threading.Lock()

    def allow(self, key: str) -> bool:
        now = time.time()
        with self._lock:
            timestamps = self._buckets.get(key, [])
            cutoff = now - self.window_seconds
            timestamps = [t for t in timestamps if t > cutoff]
            if len(timestamps) >= self.max_requests:
                self._buckets[key] = timestamps
                return False
            timestamps.append(now)
            self._buckets[key] = timestamps
            return True


class SecurityManager:
    """Handles pairing PIN, session tokens, CSRF tokens, PIN attempt lockouts, and file safety."""

    def __init__(
        self,
        pin: Optional[str] = None,
        session_ttl_seconds: int = 21600,
        max_pin_attempts: int = 8,
    ) -> None:
        self._lock = threading.Lock()
        self.pin = pin or f"{secrets.randbelow(900000) + 100000:06d}"
        self.session_ttl_seconds = session_ttl_seconds
        self.max_pin_attempts = max_pin_attempts
        self._failed_attempts: Dict[str, Tuple[int, float]] = {}
        self._sessions: Dict[str, Dict[str, object]] = {}
        self._csrf_tokens: Dict[str, float] = {}

    def get_pin(self) -> str:
        with self._lock:
            return self.pin

    def set_pin(self, new_pin: str) -> Tuple[bool, str]:
        cleaned = re.sub(r"\D", "", new_pin or "")
        if len(cleaned) < 4 or len(cleaned) > 10:
            return False, "Pairing PIN must be 4 to 10 digits."
        with self._lock:
            self.pin = cleaned
        return True, "Pairing PIN updated."

    def rotate_pin(self) -> str:
        with self._lock:
            self.pin = f"{secrets.randbelow(900000) + 100000:06d}"
            return self.pin

    def check_pin_lockout(self, ip: str) -> Tuple[bool, int]:
        """Return (is_locked, seconds_remaining)."""
        now = time.time()
        with self._lock:
            entry = self._failed_attempts.get(ip)
            if not entry:
                return False, 0
            failures, locked_until = entry
            if locked_until > now:
                return True, int(locked_until - now) + 1
            if failures >= self.max_pin_attempts:
                del self._failed_attempts[ip]
            return False, 0

    def verify_pin(self, ip: str, submitted_pin: str) -> Tuple[bool, str]:
        locked, remaining = self.check_pin_lockout(ip)
        if locked:
            return False, f"Too many incorrect PIN attempts. Try again in {remaining}s."

        with self._lock:
            expected = self.pin
            is_match = hmac.compare_digest((submitted_pin or "").strip(), expected)
            if is_match:
                self._failed_attempts.pop(ip, None)
                return True, "PIN verified."

            prev_failures, _ = self._failed_attempts.get(ip, (0, 0.0))
            failures = prev_failures + 1
            lock_until = time.time() + 120.0 if failures >= self.max_pin_attempts else 0.0
            self._failed_attempts[ip] = (failures, lock_until)
            if lock_until > 0:
                return False, "Incorrect PIN. Temporarily locked for 120 seconds."
            return False, f"Incorrect PIN ({failures}/{self.max_pin_attempts} attempts used)."

    def issue_session(self, device_id: str, ip: str) -> str:
        token = secrets.token_urlsafe(32)
        now = time.time()
        with self._lock:
            self._sessions[token] = {
                "device_id": device_id,
                "ip": ip,
                "created_at": now,
                "last_seen": now,
                "expires_at": now + self.session_ttl_seconds,
            }
        return token

    def validate_session(self, token: Optional[str], ip: Optional[str] = None) -> Optional[Dict[str, object]]:
        if not token:
            return None
        now = time.time()
        with self._lock:
            sess = self._sessions.get(token)
            if not sess:
                return None
            if now > float(sess["expires_at"]):
                del self._sessions[token]
                return None
            if ip and sess.get("ip") and sess.get("ip") != ip:
                return None
            sess["last_seen"] = now
            return dict(sess)

    def revoke_session_by_device(self, device_id: str) -> None:
        with self._lock:
            to_delete = [tok for tok, data in self._sessions.items() if data.get("device_id") == device_id]
            for tok in to_delete:
                del self._sessions[tok]

    def issue_csrf_token(self) -> str:
        token = secrets.token_urlsafe(24)
        now = time.time()
        with self._lock:
            # Prune old CSRF tokens
            expired = [k for k, exp in self._csrf_tokens.items() if exp < now]
            for k in expired:
                del self._csrf_tokens[k]
            self._csrf_tokens[token] = now + self.session_ttl_seconds
        return token

    def verify_csrf_token(self, token: Optional[str]) -> bool:
        if not token:
            return False
        now = time.time()
        with self._lock:
            exp = self._csrf_tokens.get(token)
            if not exp or exp < now:
                return False
            return True

    @staticmethod
    def sanitize_filename(filename: Optional[str]) -> str:
        """Remove directory components, null bytes, and control characters from a filename."""
        if not filename:
            return "unnamed_file"
        base = os.path.basename(filename.replace("\\", "/")).replace("\x00", "")
        cleaned = re.sub(r"[\r\n\t\x00-\x1f\x7f]", "", base).strip()
        cleaned = cleaned.strip(".")
        cleaned = re.sub(r'[<>:"/\\|?*]+', "_", cleaned)
        if not cleaned:
            return "unnamed_file"
        return cleaned[:220]

    @staticmethod
    def is_safe_subpath(root_dir: Path, candidate_path: Path) -> bool:
        """Ensure candidate_path resolves strictly inside root_dir."""
        try:
            resolved_root = root_dir.resolve()
            resolved_candidate = candidate_path.resolve()
            return resolved_candidate == resolved_root or resolved_root in resolved_candidate.parents
        except OSError:
            return False

    @classmethod
    def allocate_non_overwriting_path(cls, directory: Path, raw_filename: str) -> Path:
        """Return a safe path inside directory that never overwrites an existing file."""
        directory.mkdir(parents=True, exist_ok=True)
        safe_name = cls.sanitize_filename(raw_filename)
        candidate = directory / safe_name
        if not cls.is_safe_subpath(directory, candidate):
            candidate = directory / f"file_{secrets.token_hex(4)}"

        if not candidate.exists():
            return candidate

        stem = candidate.stem or "file"
        suffix = candidate.suffix
        counter = 1
        while True:
            numbered = directory / f"{stem} ({counter}){suffix}"
            if not numbered.exists():
                return numbered
            counter += 1