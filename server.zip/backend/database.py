import sqlite3
import threading
import time
from pathlib import Path
from typing import Any, Dict, List, Optional


class DatabaseManager:
    """SQLite persistence for SHIVSHARE LAN transfer history and settings."""

    def __init__(self, db_path: Path) -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._init_schema()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path), timeout=30.0, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA synchronous=NORMAL;")
        conn.execute("PRAGMA foreign_keys=ON;")
        return conn

    def _init_schema(self) -> None:
        with self._lock:
            with self._connect() as conn:
                conn.execute(
                    """
                    CREATE TABLE IF NOT EXISTS transfer_history (
                        transfer_id TEXT PRIMARY KEY,
                        filename TEXT NOT NULL,
                        file_size INTEGER NOT NULL DEFAULT 0,
                        sender_device TEXT NOT NULL,
                        receiver_device TEXT NOT NULL,
                        direction TEXT NOT NULL DEFAULT 'upload',
                        created_at REAL NOT NULL,
                        completed_at REAL,
                        status TEXT NOT NULL,
                        duration_seconds REAL NOT NULL DEFAULT 0.0,
                        avg_speed_bps REAL NOT NULL DEFAULT 0.0,
                        error_message TEXT
                    )
                    """
                )
                conn.execute(
                    """
                    CREATE INDEX IF NOT EXISTS idx_transfer_history_created_at
                    ON transfer_history (created_at DESC)
                    """
                )
                conn.execute(
                    """
                    CREATE INDEX IF NOT EXISTS idx_transfer_history_status
                    ON transfer_history (status)
                    """
                )
                conn.execute(
                    """
                    CREATE TABLE IF NOT EXISTS app_settings (
                        key TEXT PRIMARY KEY,
                        value TEXT NOT NULL,
                        updated_at REAL NOT NULL
                    )
                    """
                )
                conn.commit()

    def upsert_transfer(self, record: Dict[str, Any]) -> None:
        """Insert or update a transfer history record."""
        with self._lock:
            with self._connect() as conn:
                conn.execute(
                    """
                    INSERT INTO transfer_history (
                        transfer_id, filename, file_size, sender_device, receiver_device,
                        direction, created_at, completed_at, status, duration_seconds,
                        avg_speed_bps, error_message
                    ) VALUES (
                        :transfer_id, :filename, :file_size, :sender_device, :receiver_device,
                        :direction, :created_at, :completed_at, :status, :duration_seconds,
                        :avg_speed_bps, :error_message
                    )
                    ON CONFLICT(transfer_id) DO UPDATE SET
                        filename = excluded.filename,
                        file_size = excluded.file_size,
                        sender_device = excluded.sender_device,
                        receiver_device = excluded.receiver_device,
                        direction = excluded.direction,
                        completed_at = excluded.completed_at,
                        status = excluded.status,
                        duration_seconds = excluded.duration_seconds,
                        avg_speed_bps = excluded.avg_speed_bps,
                        error_message = excluded.error_message
                    """,
                    {
                        "transfer_id": record["transfer_id"],
                        "filename": record["filename"],
                        "file_size": int(record.get("file_size", 0)),
                        "sender_device": record.get("sender_device", "Unknown Device"),
                        "receiver_device": record.get("receiver_device", "SHIVSHARE Host"),
                        "direction": record.get("direction", "upload"),
                        "created_at": float(record.get("created_at", time.time())),
                        "completed_at": record.get("completed_at"),
                        "status": record.get("status", "pending"),
                        "duration_seconds": float(record.get("duration_seconds", 0.0)),
                        "avg_speed_bps": float(record.get("avg_speed_bps", 0.0)),
                        "error_message": record.get("error_message"),
                    },
                )
                conn.commit()

    def list_transfers(
        self,
        status: Optional[str] = None,
        search: Optional[str] = None,
        limit: int = 200,
    ) -> List[Dict[str, Any]]:
        """Query transfer history with optional status filter and search term."""
        clauses: List[str] = []
        params: List[Any] = []

        if status and status.lower() != "all":
            clauses.append("LOWER(status) = LOWER(?)")
            params.append(status.strip())

        if search and search.strip():
            term = f"%{search.strip()}%"
            clauses.append("(filename LIKE ? OR sender_device LIKE ? OR receiver_device LIKE ?)")
            params.extend([term, term, term])

        sql = "SELECT * FROM transfer_history"
        if clauses:
            sql += " WHERE " + " AND ".join(clauses)
        sql += " ORDER BY created_at DESC LIMIT ?"
        params.append(max(1, min(int(limit), 1000)))

        with self._lock:
            with self._connect() as conn:
                rows = conn.execute(sql, params).fetchall()
                return [dict(row) for row in rows]

    def clear_history(self) -> int:
        """Delete all transfer history rows and return deleted count."""
        with self._lock:
            with self._connect() as conn:
                cursor = conn.execute("DELETE FROM transfer_history")
                conn.commit()
                return cursor.rowcount

    def get_setting(self, key: str, default: Optional[str] = None) -> Optional[str]:
        with self._lock:
            with self._connect() as conn:
                row = conn.execute("SELECT value FROM app_settings WHERE key = ?", (key,)).fetchone()
                return row["value"] if row else default

    def set_setting(self, key: str, value: str) -> None:
        with self._lock:
            with self._connect() as conn:
                conn.execute(
                    """
                    INSERT INTO app_settings (key, value, updated_at)
                    VALUES (?, ?, ?)
                    ON CONFLICT(key) DO UPDATE SET
                        value = excluded.value,
                        updated_at = excluded.updated_at
                    """,
                    (key, str(value), time.time()),
                )
                conn.commit()

    def get_all_settings(self) -> Dict[str, str]:
        with self._lock:
            with self._connect() as conn:
                rows = conn.execute("SELECT key, value FROM app_settings").fetchall()
                return {row["key"]: row["value"] for row in rows}