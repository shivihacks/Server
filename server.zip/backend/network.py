import socket
import subprocess
from typing import Dict, List, Optional


def _get_ip_via_udp_probe() -> Optional[str]:
    """Use a non-routed UDP socket connect to discover the preferred outbound LAN IP."""
    sock = None
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(1.0)
        # Does not send packets; kernel selects source interface IP for RFC1918 LAN target
        sock.connect(("192.168.1.254", 80))
        ip = sock.getsockname()[0]
        if ip and not ip.startswith("127.") and not ip.startswith("169.254."):
            return ip
    except OSError:
        pass
    finally:
        if sock:
            sock.close()
    return None


def _get_ips_from_hostname() -> List[str]:
    """Collect IPv4 addresses associated with local hostnames."""
    found: List[str] = []
    try:
        hostname = socket.gethostname()
        infos = socket.getaddrinfo(hostname, None, family=socket.AF_INET, type=socket.SOCK_STREAM)
        for info in infos:
            ip = info[4][0]
            if ip and not ip.startswith("127.") and not ip.startswith("169.254.") and ip not in found:
                found.append(ip)
    except OSError:
        pass
    return found


def _get_ips_from_ip_cmd() -> List[str]:
    """Parse `ip -4 -o addr show` on Linux/Android Termux if available."""
    ips: List[str] = []
    try:
        proc = subprocess.run(
            ["ip", "-4", "-o", "addr", "show", "up"],
            capture_output=True,
            text=True,
            timeout=2.0,
            check=False,
        )
        if proc.returncode == 0:
            for line in proc.stdout.splitlines():
                parts = line.split()
                if "inet" in parts:
                    idx = parts.index("inet") + 1
                    if idx < len(parts):
                        cidr = parts[idx]
                        ip = cidr.split("/")[0]
                        if ip and not ip.startswith("127.") and not ip.startswith("169.254.") and ip not in ips:
                            ips.append(ip)
    except (OSError, subprocess.SubprocessError):
        pass
    return ips


def detect_local_ip() -> str:
    """Dynamically detect the active local LAN or hotspot IPv4 address."""
    candidates: List[str] = []

    cmd_ips = _get_ips_from_ip_cmd()
    candidates.extend(cmd_ips)

    udp_ip = _get_ip_via_udp_probe()
    if udp_ip and udp_ip not in candidates:
        candidates.insert(0, udp_ip)

    for ip in _get_ips_from_hostname():
        if ip not in candidates:
            candidates.append(ip)

    # Prioritize private LAN/hotspot ranges
    for prefix in ("192.168.", "172.", "10."):
        for ip in candidates:
            if ip.startswith(prefix):
                return ip

    if candidates:
        return candidates[0]

    return "127.0.0.1"


def get_network_info(port: int = 8080) -> Dict[str, object]:
    """Return structured LAN and hotspot status for CLI and API consumers."""
    local_ip = detect_local_ip()
    all_ips = _get_ips_from_ip_cmd() or ([local_ip] if local_ip != "127.0.0.1" else [])
    is_lan = local_ip != "127.0.0.1"

    return {
        "local_ip": local_ip,
        "port": port,
        "url": f"http://{local_ip}:{port}",
        "all_ips": all_ips,
        "network_type": "Wi-Fi / Hotspot LAN" if is_lan else "Loopback Only (No LAN IP Detected)",
        "internet_required": False,
        "ap_isolation_note": (
            "If another phone cannot load the URL on a shared router, AP Isolation may be enabled. "
            "Use one phone's Mobile Hotspot and connect the second phone directly to it."
        ),
    }