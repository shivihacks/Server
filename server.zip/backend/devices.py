import threading
import time
import uuid
from typing import Any, Dict, List, Optional


def parse_device_type(user_agent: str) -> str:
    ua = (user_agent or "").lower()
    if "android" in ua:
        return "Android Phone"
    if "iphone" in ua or "ipad" in ua or "ios" in ua:
        return "iOS Device"
    if "windows" in ua:
        return "Windows PC"
    if "mac os" in ua or "macintosh" in ua:
        return "macOS Device"
    if "linux" in ua:
        return "Linux Device"
    return "Mobile / Web Client"


class DeviceManager:
    """Manages connected peer devices, pairing sessions, and approval states."""

    def __init__(self, host_name: str = "SHIVSHARE Host (Termux)", host_ip: str = "127.0.0.1") -> None:
        self._lock = threading.Lock()
        self.host_device = {
            "device_id": "host-device",
            "name": host_name,
            "ip": host_ip,
            "device_type": "Android Termux Server",
            "status": "connected",
            "connected_at": time.time(),
            "last_seen": time.time(),
            "is_host": True,
        }
        self._devices: Dict[str, Dict[str, Any]] = {}

    def update_host_ip(self, ip: str) -> None:
        with self._lock:
            self.host_device["ip"] = ip

    def register_or_refresh_request(
        self,
        device_name: str,
        ip: str,
        user_agent: str,
        device_type: Optional[str] = None,
        existing_device_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        now = time.time()
        clean_name = (device_name or "").strip()[:80]
        detected_type = (device_type or "").strip()[:40] or parse_device_type(user_agent)
        if not clean_name:
            clean_name = detected_type

        with self._lock:
            if existing_device_id and existing_device_id in self._devices:
                dev = self._devices[existing_device_id]
                dev["name"] = clean_name
                dev["ip"] = ip
                dev["device_type"] = detected_type
                dev["last_seen"] = now
                if dev["status"] == "disconnected":
                    dev["status"] = "pending_approval"
                return dict(dev)

            device_id = f"dev_{uuid.uuid4().hex[:12]}"
            dev = {
                "device_id": device_id,
                "name": clean_name,
                "ip": ip,
                "device_type": detected_type,
                "status": "pending_approval",
                "connected_at": now,
                "last_seen": now,
                "is_host": False,
            }
            self._devices[device_id] = dev
            return dict(dev)

    def approve_device(self, device_id: str) -> Optional[Dict[str, Any]]:
        with self._lock:
            dev = self._devices.get(device_id)
            if not dev:
                return None
            dev["status"] = "approved"
            dev["last_seen"] = time.time()
            return dict(dev)

    def reject_device(self, device_id: str) -> Optional[Dict[str, Any]]:
        with self._lock:
            dev = self._devices.get(device_id)
            if not dev:
                return None
            dev["status"] = "rejected"
            dev["last_seen"] = time.time()
            return dict(dev)

    def disconnect_device(self, device_id: str) -> Optional[Dict[str, Any]]:
        with self._lock:
            dev = self._devices.get(device_id)
            if not dev:
                return None
            dev["status"] = "disconnected"
            dev["last_seen"] = time.time()
            return dict(dev)

    def touch_device(self, device_id: str) -> None:
        with self._lock:
            dev = self._devices.get(device_id)
            if dev:
                dev["last_seen"] = time.time()
                if dev["status"] == "disconnected":
                    dev["status"] = "approved"

    def get_device(self, device_id: str) -> Optional[Dict[str, Any]]:
        with self._lock:
            dev = self._devices.get(device_id)
            return dict(dev) if dev else None

    def is_approved(self, device_id: str) -> bool:
        with self._lock:
            dev = self._devices.get(device_id)
            return bool(dev and dev.get("status") == "approved")

    def list_devices(self, include_host: bool = True) -> List[Dict[str, Any]]:
        with self._lock:
            items: List[Dict[str, Any]] = []
            if include_host:
                items.append(dict(self.host_device))
            items.extend(dict(d) for d in self._devices.values())
            return items