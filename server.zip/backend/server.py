import json
import os
import queue
import time
from functools import wraps
from pathlib import Path
from typing import Any, Callable, Dict, Optional

from flask import (
    Flask,
    Response,
    jsonify,
    make_response,
    render_template,
    request,
    send_file,
    stream_with_context,
)
from werkzeug.exceptions import RequestEntityTooLarge

from config import (
    APP_NAME,
    APP_VERSION,
    CHUNK_SIZE,
    HOST_PORT,
    MAX_FILE_SIZE_BYTES,
    MAX_PIN_ATTEMPTS,
    RATE_LIMIT_MAX_REQUESTS,
    RATE_LIMIT_WINDOW_SECONDS,
    RECEIVED_DIR,
    SECRET_KEY,
    SESSION_TTL_SECONDS,
    TEMP_DIR,
    ensure_directories,
)
from backend.database import DatabaseManager
from backend.devices import DeviceManager
from backend.file_manager import FileManager
from backend.network import get_network_info
from backend.security import RateLimiter, SecurityManager
from backend.transfer import TransferManager


def _client_ip() -> str:
    remote = request.remote_addr or "127.0.0.1"
    return remote.replace("::ffff:", "")


def create_app(initial_pin: Optional[str] = None, port: int = HOST_PORT) -> Flask:
    ensure_directories()

    project_root = Path(__file__).resolve().parent.parent
    app = Flask(
        __name__,
        template_folder=str(project_root / "templates"),
        static_folder=str(project_root / "static"),
    )
    app.config["SECRET_KEY"] = SECRET_KEY
    app.config["MAX_CONTENT_LENGTH"] = MAX_FILE_SIZE_BYTES

    db = DatabaseManager(project_root / "database" / "shivshare.db")
    saved_pin = db.get_setting("pairing_pin")
    security = SecurityManager(
        pin=initial_pin or saved_pin,
        session_ttl_seconds=SESSION_TTL_SECONDS,
        max_pin_attempts=MAX_PIN_ATTEMPTS,
    )
    rate_limiter = RateLimiter(
        max_requests=RATE_LIMIT_MAX_REQUESTS,
        window_seconds=RATE_LIMIT_WINDOW_SECONDS,
    )

    net_info = get_network_info(port=port)
    host_name = db.get_setting("device_name", "SHIVSHARE Host (Termux)") or "SHIVSHARE Host (Termux)"
    devices = DeviceManager(host_name=host_name, host_ip=str(net_info["local_ip"]))
    files = FileManager(received_dir=RECEIVED_DIR, temp_dir=TEMP_DIR)
    transfers = TransferManager(db=db, received_dir=RECEIVED_DIR, temp_dir=TEMP_DIR)

    # SSE event queues for live updates
    sse_subscribers: list[queue.Queue[str]] = []
    sse_lock = __import__("threading").Lock()

    def broadcast_sse(event_payload: Dict[str, Any]) -> None:
        encoded = json.dumps(event_payload)
        with sse_lock:
            for q in list(sse_subscribers):
                try:
                    q.put_nowait(encoded)
                except queue.Full:
                    pass

    transfers.subscribe(broadcast_sse)

    # Attach managers on app for CLI inspection if desired
    app.extensions["shivshare"] = {
        "db": db,
        "security": security,
        "devices": devices,
        "files": files,
        "transfers": transfers,
        "port": port,
    }

    def is_local_host_request() -> bool:
        ip = _client_ip()
        local_ip = str(get_network_info(port=port)["local_ip"])
        return ip in ("127.0.0.1", "::1", local_ip)

    def get_current_peer() -> Optional[Dict[str, Any]]:
        token = request.headers.get("X-ShivShare-Session") or request.cookies.get("shivshare_session")
        sess = security.validate_session(token, ip=_client_ip())
        if not sess:
            return None
        dev_id = str(sess.get("device_id", ""))
        dev = devices.get_device(dev_id)
        if not dev:
            return None
        devices.touch_device(dev_id)
        return dev

    def require_paired_or_local(fn: Callable[..., Any]) -> Callable[..., Any]:
        @wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            peer = get_current_peer()
            if peer and peer.get("status") == "approved":
                return fn(*args, peer=peer, **kwargs)
            if is_local_host_request():
                return fn(*args, peer=devices.host_device, **kwargs)
            return jsonify({"ok": False, "error": "Pairing and host approval required."}), 403

        return wrapper

    def require_host_or_paired(fn: Callable[..., Any]) -> Callable[..., Any]:
        @wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            peer = get_current_peer()
            if peer and peer.get("status") == "approved":
                return fn(*args, peer=peer, **kwargs)
            if is_local_host_request():
                return fn(*args, peer=devices.host_device, **kwargs)
            return jsonify({"ok": False, "error": "Unauthorized device."}), 403

        return wrapper

    @app.before_request
    def security_gate() -> Optional[Any]:
        ip = _client_ip()
        if not rate_limiter.allow(ip):
            return jsonify({"ok": False, "error": "Rate limit exceeded. Slow down requests."}), 429

        if request.method in ("POST", "PUT", "PATCH", "DELETE"):
            # Allow multipart uploads / pairing requests that carry session/CSRF or JSON body
            csrf = request.headers.get("X-CSRF-Token")
            if not csrf and request.is_json:
                data = request.get_json(silent=True) or {}
                csrf = data.get("csrf_token")
            if not csrf and request.form:
                csrf = request.form.get("csrf_token")
            if not security.verify_csrf_token(csrf):
                return jsonify({"ok": False, "error": "Invalid or missing CSRF token."}), 403
        return None

    @app.errorhandler(RequestEntityTooLarge)
    def handle_too_large(_err: RequestEntityTooLarge) -> Any:
        return jsonify({"ok": False, "error": "Uploaded file exceeds size limit."}), 413

    # ------------------ Web Pages ------------------

    @app.get("/")
    def index_page() -> str:
        csrf_token = security.issue_csrf_token()
        net = get_network_info(port=port)
        devices.update_host_ip(str(net["local_ip"]))
        peer = get_current_peer()
        return render_template(
            "index.html",
            app_name=APP_NAME,
            app_version=APP_VERSION,
            csrf_token=csrf_token,
            network=net,
            is_local_host=is_local_host_request(),
            peer_device=peer,
            host_pin=security.get_pin() if is_local_host_request() else None,
        )

    @app.get("/partials/<section_name>")
    def partial_page(section_name: str) -> Any:
        allowed = {
            "dashboard": "dashboard.html",
            "files": "files.html",
            "devices": "devices.html",
            "transfers": "transfers.html",
            "settings": "settings.html",
        }
        tpl = allowed.get(section_name)
        if not tpl:
            return jsonify({"ok": False, "error": "Section not found."}), 404
        return render_template(tpl, app_name=APP_NAME, app_version=APP_VERSION)

    # ------------------ Status & Live Events ------------------

    @app.get("/api/status")
    def api_status() -> Any:
        net = get_network_info(port=port)
        devices.update_host_ip(str(net["local_ip"]))
        local_host = is_local_host_request()
        peer = get_current_peer()
        return jsonify(
            {
                "ok": True,
                "app_name": APP_NAME,
                "app_version": APP_VERSION,
                "status": "RUNNING",
                "network": net,
                "storage": files.check_storage_permissions(),
                "is_local_host": local_host,
                "peer_device": peer,
                "pairing_pin": security.get_pin() if local_host else None,
                "connected_count": sum(1 for d in devices.list_devices() if d.get("status") == "connected" or d.get("status") == "approved"),
            }
        )

    @app.get("/api/events")
    def api_events() -> Response:
        """Server-Sent Events stream for real-time transfer progress and device updates."""
        q: queue.Queue[str] = queue.Queue(maxsize=100)
        with sse_lock:
            sse_subscribers.append(q)

        @stream_with_context
        def event_stream():
            try:
                yield f"data: {json.dumps({'type': 'connected', 'ts': time.time()})}\n\n"
                while True:
                    try:
                        msg = q.get(timeout=15.0)
                        yield f"data: {msg}\n\n"
                    except queue.Empty:
                        yield ": keepalive\n\n"
            finally:
                with sse_lock:
                    if q in sse_subscribers:
                        sse_subscribers.remove(q)

        return Response(event_stream(), mimetype="text/event-stream", headers={"Cache-Control": "no-cache"})

    # ------------------ Device Pairing & Approval ------------------

    @app.post("/api/pair/request")
    def pair_request() -> Any:
        data = request.get_json(silent=True) or {}
        pin = str(data.get("pin", "")).strip()
        device_name = str(data.get("device_name", "")).strip()
        device_type = str(data.get("device_type", "")).strip() or None
        existing_id = str(data.get("device_id", "")).strip() or None
        ip = _client_ip()

        ok_pin, pin_msg = security.verify_pin(ip, pin)
        if not ok_pin:
            return jsonify({"ok": False, "error": pin_msg}), 401

        dev = devices.register_or_refresh_request(
            device_name=device_name,
            ip=ip,
            user_agent=request.headers.get("User-Agent", ""),
            device_type=device_type,
            existing_device_id=existing_id,
        )
        token = security.issue_session(dev["device_id"], ip=ip)
        broadcast_sse({"type": "device_update", "devices": devices.list_devices()})

        resp = make_response(
            jsonify(
                {
                    "ok": True,
                    "message": "PIN accepted. Waiting for host approval.",
                    "device": dev,
                    "session_token": token,
                }
            )
        )
        resp.set_cookie("shivshare_session", token, httponly=True, samesite="Lax", max_age=SESSION_TTL_SECONDS)
        return resp

    @app.get("/api/pair/status")
    def pair_status() -> Any:
        peer = get_current_peer()
        if not peer:
            dev_id = request.args.get("device_id", "").strip()
            dev = devices.get_device(dev_id) if dev_id else None
            return jsonify({"ok": True, "device": dev, "approved": False})
        return jsonify({"ok": True, "device": peer, "approved": peer.get("status") == "approved"})

    @app.get("/api/devices")
    def list_devices() -> Any:
        return jsonify({"ok": True, "devices": devices.list_devices(include_host=True)})

    @app.post("/api/devices/<device_id>/approve")
    @require_host_or_paired
    def approve_device(device_id: str, peer: Dict[str, Any]) -> Any:
        if not is_local_host_request() and peer.get("device_id") != "host-device":
            return jsonify({"ok": False, "error": "Only the host device can approve connections."}), 403
        updated = devices.approve_device(device_id)
        if not updated:
            return jsonify({"ok": False, "error": "Device not found."}), 404
        broadcast_sse({"type": "device_update", "devices": devices.list_devices()})
        return jsonify({"ok": True, "device": updated})

    @app.post("/api/devices/<device_id>/reject")
    @require_host_or_paired
    def reject_device(device_id: str, peer: Dict[str, Any]) -> Any:
        if not is_local_host_request():
            return jsonify({"ok": False, "error": "Only the host device can reject connections."}), 403
        updated = devices.reject_device(device_id)
        if not updated:
            return jsonify({"ok": False, "error": "Device not found."}), 404
        security.revoke_session_by_device(device_id)
        broadcast_sse({"type": "device_update", "devices": devices.list_devices()})
        return jsonify({"ok": True, "device": updated})

    @app.post("/api/devices/<device_id>/disconnect")
    @require_paired_or_local
    def disconnect_device(device_id: str, peer: Dict[str, Any]) -> Any:
        updated = devices.disconnect_device(device_id)
        if not updated:
            return jsonify({"ok": False, "error": "Device not found."}), 404
        security.revoke_session_by_device(device_id)
        broadcast_sse({"type": "device_update", "devices": devices.list_devices()})
        return jsonify({"ok": True, "device": updated})

    # ------------------ File Manager ------------------

    @app.get("/api/files")
    @require_paired_or_local
    def api_list_files(peer: Dict[str, Any]) -> Any:
        files.refresh_authorized_roots()
        root_id = request.args.get("root_id", "received")
        subpath = request.args.get("subpath", "")
        category = request.args.get("category", "all")
        search = request.args.get("search", "")
        sort_by = request.args.get("sort_by", "name")
        sort_order = request.args.get("sort_order", "asc")

        data = files.list_items(
            root_id=root_id,
            subpath=subpath,
            category=category,
            search=search,
            sort_by=sort_by,
            sort_order=sort_order,
        )
        if "error" in data:
            return jsonify({"ok": False, **data}), 400
        return jsonify({"ok": True, **data})

    @app.get("/api/files/download")
    @require_paired_or_local
    def api_download_file(peer: Dict[str, Any]) -> Any:
        root_id = request.args.get("root_id", "received")
        rel_path = request.args.get("path", "")
        resolved = files.resolve_safe_path(root_id, rel_path)
        if not resolved:
            return jsonify({"ok": False, "error": "Invalid or unauthorized file path."}), 403
        _, target = resolved
        if not target.exists() or not target.is_file():
            return jsonify({"ok": False, "error": "File not found."}), 404

        file_size = target.stat().st_size
        started = time.time()

        @stream_with_context
        def generate():
            with open(target, "rb") as f:
                while True:
                    chunk = f.read(CHUNK_SIZE)
                    if not chunk:
                        break
                    yield chunk
            elapsed = time.time() - started
            sender_name = devices.host_device["name"] if root_id != "received" else "SHIVSHARE Storage"
            transfers.record_download_completed(
                filename=target.name,
                file_size=file_size,
                sender_device=sender_name,
                receiver_device=peer.get("name", "Connected Device"),
                duration_seconds=elapsed,
            )

        headers = {
            "Content-Length": str(file_size),
            "Content-Disposition": f'attachment; filename="{security.sanitize_filename(target.name)}"',
        }
        return Response(generate(), mimetype="application/octet-stream", headers=headers)

    @app.delete("/api/files/received")
    @require_paired_or_local
    def api_delete_received(peer: Dict[str, Any]) -> Any:
        rel_path = request.args.get("path", "")
        ok, msg = files.delete_received_file(rel_path)
        if not ok:
            return jsonify({"ok": False, "error": msg}), 400
        return jsonify({"ok": True, "message": msg})

    # ------------------ Transfers (Upload, Approval, Progress, Cancel, History) ------------------

    @app.post("/api/transfers/init")
    @require_paired_or_local
    def init_transfer(peer: Dict[str, Any]) -> Any:
        data = request.get_json(silent=True) or {}
        filename = str(data.get("filename", "")).strip()
        file_size = int(data.get("file_size", 0) or 0)
        sender_name = str(data.get("sender_device") or peer.get("name") or "Peer Device")
        receiver_name = str(data.get("receiver_device") or devices.host_device["name"])
        auto_accept = bool(data.get("auto_accept", False)) and is_local_host_request()

        if not filename:
            return jsonify({"ok": False, "error": "Filename is required."}), 400

        ok, msg, info = transfers.create_incoming_request(
            raw_filename=filename,
            file_size=file_size,
            sender_device=sender_name,
            receiver_device=receiver_name,
            auto_accept=auto_accept,
        )
        if not ok:
            return jsonify({"ok": False, "error": msg}), 400
        return jsonify({"ok": True, "message": msg, "transfer": info})

    @app.post("/api/transfers/<transfer_id>/decision")
    @require_paired_or_local
    def decide_transfer(transfer_id: str, peer: Dict[str, Any]) -> Any:
        data = request.get_json(silent=True) or {}
        accept = bool(data.get("accept", False))
        ok, msg, info = transfers.decide_transfer(transfer_id, accept=accept)
        if not ok:
            return jsonify({"ok": False, "error": msg}), 400
        return jsonify({"ok": True, "message": msg, "transfer": info})

    @app.post("/api/transfers/<transfer_id>/upload")
    @require_paired_or_local
    def upload_transfer_stream(transfer_id: str, peer: Dict[str, Any]) -> Any:
        """Stream file bytes directly from request body/multipart file to temp storage."""
        expected_size = int(request.headers.get("X-File-Size", "0") or "0")

        if "file" in request.files:
            uploaded_file = request.files["file"]
            stream = uploaded_file.stream
        else:
            stream = request.stream

        ok, msg, info = transfers.stream_into_session(
            transfer_id=transfer_id,
            stream=stream,
            expected_size=expected_size,
        )
        if not ok:
            return jsonify({"ok": False, "error": msg, "transfer": info}), 400
        return jsonify({"ok": True, "message": msg, "transfer": info})

    @app.post("/api/transfers/<transfer_id>/cancel")
    @require_paired_or_local
    def cancel_transfer(transfer_id: str, peer: Dict[str, Any]) -> Any:
        ok, msg, info = transfers.cancel_transfer(transfer_id)
        if not ok:
            return jsonify({"ok": False, "error": msg}), 400
        return jsonify({"ok": True, "message": msg, "transfer": info})

    @app.get("/api/transfers/active")
    @require_paired_or_local
    def active_transfers(peer: Dict[str, Any]) -> Any:
        return jsonify({"ok": True, "transfers": transfers.get_active_and_recent()})

    @app.get("/api/transfers/<transfer_id>/status")
    @require_paired_or_local
    def transfer_status(transfer_id: str, peer: Dict[str, Any]) -> Any:
        info = transfers.get_session_metrics(transfer_id)
        if not info:
            return jsonify({"ok": False, "error": "Transfer not found."}), 404
        return jsonify({"ok": True, "transfer": info})

    @app.get("/api/history")
    @require_paired_or_local
    def transfer_history(peer: Dict[str, Any]) -> Any:
        status = request.args.get("status", "all")
        search = request.args.get("search", "")
        limit = int(request.args.get("limit", "200") or "200")
        rows = db.list_transfers(status=status, search=search, limit=limit)
        return jsonify({"ok": True, "history": rows})

    @app.delete("/api/history")
    @require_host_or_paired
    def clear_transfer_history(peer: Dict[str, Any]) -> Any:
        if not is_local_host_request():
            return jsonify({"ok": False, "error": "Only the host device can clear transfer history."}), 403
        deleted = db.clear_history()
        return jsonify({"ok": True, "deleted": deleted, "message": "Transfer history cleared."})

    # ------------------ Settings ------------------

    @app.get("/api/settings")
    def get_settings() -> Any:
        stored = db.get_all_settings()
        return jsonify(
            {
                "ok": True,
                "settings": {
                    "device_name": devices.host_device["name"],
                    "theme": stored.get("theme", "dark"),
                    "auto_accept_local": stored.get("auto_accept_local", "false") == "true",
                    "pairing_pin": security.get_pin() if is_local_host_request() else None,
                },
            }
        )

    @app.post("/api/settings")
    @require_host_or_paired
    def update_settings(peer: Dict[str, Any]) -> Any:
        if not is_local_host_request():
            return jsonify({"ok": False, "error": "Only the host device can change server settings."}), 403
        data = request.get_json(silent=True) or {}

        if "device_name" in data and str(data["device_name"]).strip():
            new_name = str(data["device_name"]).strip()[:80]
            devices.host_device["name"] = new_name
            db.set_setting("device_name", new_name)

        if "theme" in data and str(data["theme"]) in ("dark", "light"):
            db.set_setting("theme", str(data["theme"]))

        if "auto_accept_local" in data:
            db.set_setting("auto_accept_local", "true" if bool(data["auto_accept_local"]) else "false")

        if data.get("rotate_pin"):
            new_pin = security.rotate_pin()
            db.set_setting("pairing_pin", new_pin)

        return jsonify(
            {
                "ok": True,
                "message": "Settings saved.",
                "device_name": devices.host_device["name"],
                "pairing_pin": security.get_pin(),
            }
        )

    return app