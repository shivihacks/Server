(function () {
  const { formatBytes, apiFetch, escapeHtml } = window.ShivShare;

  const fmState = {
    rootId: "received",
    subpath: "",
    category: "all",
    search: "",
    sortBy: "name",
    sortOrder: "asc",
    viewMode: "grid",
    selectedPaths: new Set(),
    currentFiles: [],
    initialized: false,
  };

  function updateSelectionBar() {
    const bar = document.getElementById("fmSelectionBar");
    const countEl = document.getElementById("fmSelectedCount");
    if (!bar || !countEl) return;
    const count = fmState.selectedPaths.size;
    countEl.textContent = `${count} selected`;
    bar.classList.toggle("hidden", count === 0);
  }

  async function loadFiles() {
    const params = new URLSearchParams({
      root_id: fmState.rootId,
      subpath: fmState.subpath,
      category: fmState.category,
      search: fmState.search,
      sort_by: fmState.sortBy,
      sort_order: fmState.sortOrder,
    });

    const { data } = await apiFetch(`/api/files?${params.toString()}`);
    if (!data || !data.ok) {
      const container = document.getElementById("fmItemsContainer");
      if (container) container.innerHTML = `<p class="muted">${escapeHtml(data?.error || "Unable to list files.")}</p>`;
      return;
    }

    const rootSelect = document.getElementById("fmRootSelect");
    if (rootSelect && data.roots) {
      rootSelect.innerHTML = Object.values(data.roots)
        .map((r) => `<option value="${escapeHtml(r.id)}" ${r.id === fmState.rootId ? "selected" : ""}>${escapeHtml(r.label)}</option>`)
        .join("");
    }

    const bc = document.getElementById("fmBreadcrumb");
    if (bc) {
      const label = data.roots?.[fmState.rootId]?.label || fmState.rootId;
      bc.textContent = fmState.subpath ? `${label} / ${fmState.subpath}` : `${label} /`;
    }

    const foldersRow = document.getElementById("fmFoldersRow");
    if (foldersRow) {
      const folderButtons = [];
      if (fmState.subpath) {
        const parts = fmState.subpath.split("/");
        parts.pop();
        folderButtons.push(
          `<button class="folder-chip" type="button" onclick="window.ShivShare.fmNavigate('${escapeHtml(parts.join("/"))}')">⬅ .. (Up)</button>`
        );
      }
      (data.folders || []).forEach((folder) => {
        folderButtons.push(
          `<button class="folder-chip" type="button" onclick="window.ShivShare.fmNavigate('${escapeHtml(folder.rel_path)}')">📁 ${escapeHtml(folder.name)}</button>`
        );
      });
      foldersRow.innerHTML = folderButtons.join("");
    }

    fmState.currentFiles = data.files || [];
    const itemsEl = document.getElementById("fmItemsContainer");
    if (!itemsEl) return;
    itemsEl.className = fmState.viewMode === "list" ? "files-list" : "files-grid";

    if (!fmState.currentFiles.length) {
      itemsEl.innerHTML = `<p class="muted">No files match the current filter.</p>`;
      return;
    }

    itemsEl.innerHTML = fmState.currentFiles
      .map((f) => {
        const checked = fmState.selectedPaths.has(f.rel_path) ? "checked" : "";
        const dlUrl = `/api/files/download?root_id=${encodeURIComponent(fmState.rootId)}&path=${encodeURIComponent(f.rel_path)}`;
        return `
        <div class="file-card">
          <div style="display:flex;align-items:flex-start;gap:8px;min-width:0;">
            <input type="checkbox" ${checked} onchange="window.ShivShare.fmToggleSelect('${escapeHtml(f.rel_path)}', this.checked)" />
            <div style="min-width:0;">
              <div class="file-name">${escapeHtml(f.name)}</div>
              <div class="file-meta">${formatBytes(f.size)} • ${escapeHtml(f.category)} • ${escapeHtml(f.modified_str || "")}</div>
            </div>
          </div>
          <a class="btn btn-secondary btn-sm" href="${dlUrl}" download>⬇ Save</a>
        </div>`;
      })
      .join("");
  }

  window.ShivShare.fmNavigate = function (newSubpath) {
    fmState.subpath = newSubpath;
    fmState.selectedPaths.clear();
    updateSelectionBar();
    loadFiles();
  };

  window.ShivShare.fmToggleSelect = function (relPath, isChecked) {
    if (isChecked) fmState.selectedPaths.add(relPath);
    else fmState.selectedPaths.delete(relPath);
    updateSelectionBar();
  };

  function bindFileManagerEvents() {
    if (fmState.initialized) return;
    fmState.initialized = true;

    document.getElementById("fmRootSelect")?.addEventListener("change", (e) => {
      fmState.rootId = e.target.value;
      fmState.subpath = "";
      fmState.selectedPaths.clear();
      updateSelectionBar();
      loadFiles();
    });

    document.getElementById("fmSearchInput")?.addEventListener("input", (e) => {
      fmState.search = e.target.value;
      loadFiles();
    });

    document.getElementById("fmSortSelect")?.addEventListener("change", (e) => {
      const [sortBy, sortOrder] = String(e.target.value || "name:asc").split(":");
      fmState.sortBy = sortBy;
      fmState.sortOrder = sortOrder;
      loadFiles();
    });

    document.querySelectorAll("#fmCategoryTabs .cat-tab").forEach((tab) => {
      tab.addEventListener("click", () => {
        document.querySelectorAll("#fmCategoryTabs .cat-tab").forEach((t) => t.classList.remove("active"));
        tab.classList.add("active");
        fmState.category = tab.dataset.cat || "all";
        loadFiles();
      });
    });

    document.getElementById("fmGridViewBtn")?.addEventListener("click", () => {
      fmState.viewMode = "grid";
      document.getElementById("fmGridViewBtn")?.classList.add("active");
      document.getElementById("fmListViewBtn")?.classList.remove("active");
      loadFiles();
    });

    document.getElementById("fmListViewBtn")?.addEventListener("click", () => {
      fmState.viewMode = "list";
      document.getElementById("fmListViewBtn")?.classList.add("active");
      document.getElementById("fmGridViewBtn")?.classList.remove("active");
      loadFiles();
    });

    document.getElementById("fmRefreshBtn")?.addEventListener("click", loadFiles);

    document.getElementById("fmSelectAllBtn")?.addEventListener("click", () => {
      fmState.currentFiles.forEach((f) => fmState.selectedPaths.add(f.rel_path));
      updateSelectionBar();
      loadFiles();
    });

    document.getElementById("fmClearSelBtn")?.addEventListener("click", () => {
      fmState.selectedPaths.clear();
      updateSelectionBar();
      loadFiles();
    });

    document.getElementById("fmDownloadSelBtn")?.addEventListener("click", () => {
      for (const relPath of fmState.selectedPaths) {
        const a = document.createElement("a");
        a.href = `/api/files/download?root_id=${encodeURIComponent(fmState.rootId)}&path=${encodeURIComponent(relPath)}`;
        a.download = "";
        document.body.appendChild(a);
        a.click();
        a.remove();
      }
    });
  }

  window.ShivShare.initFileManager = function () {
    bindFileManagerEvents();
    loadFiles();
  };
})();