window.ShivShare = window.ShivShare || {};

(function () {
  const csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute("content") || "";
  const isLocalHost = document.body.dataset.localHost === "true";

  const state = {
    section: "home",
    sessionToken: sessionStorage.getItem("shivshare_session") || "",
    deviceId: sessionStorage.getItem("shivshare_device_id") || "",
    approved: isLocalHost,
    devices: [],
    transfers: [],
    pendingApprovals: [],
    status: null,
  };

  window.ShivShare.state = state;
  window.ShivShare.csrfToken = csrfToken;

  function formatBytes(bytes) {
    const n = Number(bytes || 0);
    if (n <= 0) return "0 B";
    const units = ["B", "KB", "MB", "GB", "TB"];
    const idx = Math.min(units.length - 1, Math.floor(Math.log(n) / Math.log(1024)));
    const val = n / Math.pow(1024, idx);
    return `${val >= 100 || idx === 0 ? val.toFixed(0) : val.toFixed(1)} ${units[idx]}`;
  }

  function formatSpeed(bps) {
    const n = Number(bps || 0);
    if (n <= 0) return "0 B/s";
    return `${formatBytes(n)}/s`;
  }

  function formatEta(seconds) {
    if (seconds === null || seconds === undefined || Number.isNaN(Number(seconds))) return "--:--";
    const total = Math.max(0, Math.round(Number(seconds)));
    const mins = Math.floor(total / 60);
    const secs = total % 60;
    return `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
  }

  window.ShivShare.formatBytes = formatBytes;
  window.ShivShare.formatSpeed = formatSpeed;
  window.ShivShare.formatEta = formatEta;

  async function apiFetch(url, options = {}) {
    const headers = Object.assign({}, options.headers || {});
    if (csrfToken && options.method && options.method !== "GET") {
      headers["X-CSRF-Token"] = csrfToken;
    }
    if (state.sessionToken) {
      headers["X-ShivShare-Session"] = state.sessionToken;
    }
    const res = await fetch(url, Object.assign({}, options, { headers }));
    const data = await res.json().catch(() => ({ ok: false, error: "Invalid server response." }));
    return { status: res.status, data };
  }

  window.ShivShare.apiFetch = apiFetch;

  function applyTheme(theme) {
    const chosen = theme === "light" ? "light" : "dark";
    document.documentElement.setAttribute("data-theme", chosen);
    localStorage.setItem("shivshare_theme", chosen);
  }

  async function loadPartialIfNeeded(section) {
    const map = {
      files: { containerId: "fileManagerContainer", url: "/partials/files", initFn: () => window.ShivShare.initFileManager?.() },
      devices: { containerId: "devicesContainer", url: "/partials/devices", initFn: () => renderDevicesSection() },
      history: { containerId: "historyContainer", url: "/partials/transfers", initFn: () => loadHistorySection() },
      settings: { containerId: "settingsContainer", url: "/partials/settings", initFn: () => loadSettingsSection() },
    };
    const cfg = map[section];
    if (!cfg) return;

    const el = document.getElementById(cfg.containerId);
    if (el && !el.dataset.loaded) {
      const res = await fetch(cfg.url);
      if (res.ok) {
        el.innerHTML = await res.text();
        el.dataset.loaded = "1";
      }
    }
    cfg.initFn();
  }

  async function switchSection(section) {
    state.section = section;
    document.querySelectorAll(".view-section").forEach((sec) => {
      sec.classList.toggle("active", sec.id === `section-${section}`);
    });
    document.querySelectorAll(".nav-item, .bnav-btn").forEach((btn) => {
      btn.classList.toggle("active", btn.dataset.section === section);
    });
    document.getElementById("sidebarNav")?.classList.remove("open");
    await loadPartialIfNeeded(section);
  }

  window.ShivShare.switchSection = switchSection;

  function updatePairingGate() {
    const gate = document.getElementById("pairingBanner");
    if (!gate) return;
    if (isLocalHost || state.approved) {
      gate.classList.add("hidden");
    } else {
      gate.classList.remove("hidden");
    }
  }

  async function refreshStatusAndDevices() {
    const [{ data: st }, { data: devData }] = await Promise.all([
      apiFetch("/api/status"),
      apiFetch("/api/devices"),
    ]);

    if (st && st.ok) {
      state.status = st;
      if (st.network?.local_ip) {
        document.getElementById("liveNetText").textContent = st.network.local_ip;
        document.getElementById("homeServerUrl").textContent = st.network.url;
      }
      if (st.storage?.free_bytes !== undefined) {
        document.getElementById("homeFreeStorage").textContent = formatBytes(st.storage.free_bytes);
      }
      if (!isLocalHost && st.peer_device) {
        state.approved = st.peer_device.status === "approved";
        updatePairingGate();
      }
    }

    if (devData && devData.ok) {
      state.devices = devData.devices || [];
      const activeCount = state.devices.filter(
        (d) => d.is_host || d.status === "approved" || d.status === "connected"
      ).length;
      document.getElementById("homeDeviceCount").textContent = String(activeCount);
      populateTargetDeviceSelect();
      if (state.section === "devices") {
        renderDevicesSection();
      }
    }
  }

  function populateTargetDeviceSelect() {
    const sel = document.getElementById("targetDeviceSelect");
    if (!sel) return;
    const prev = sel.value || "host";
    const options = ['<option value="host">SHIVSHARE Host (Received Storage)</option>'];
    state.devices
      .filter((d) => !d.is_host && d.status === "approved")
      .forEach((d) => {
        options.push(`<option value="${escapeHtml(d.device_id)}">${escapeHtml(d.name)} (${escapeHtml(d.ip)})</option>`);
      });
    sel.innerHTML = options.join("");
    if ([...sel.options].some((o) => o.value === prev)) {
      sel.value = prev;
    }
  }

  function escapeHtml(str) {
    return String(str || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  window.ShivShare.escapeHtml = escapeHtml;

  function renderIncomingApprovals() {
    const pending = state.transfers.filter((t) => t.status === "pending_approval" && t.direction === "upload");
    state.pendingApprovals = pending;

    const badge = document.getElementById("pendingBadge");
    if (badge) {
      badge.textContent = String(pending.length);
      badge.classList.toggle("hidden", pending.length === 0);
    }

    const banner = document.getElementById("incomingApprovalBox");
    const meta = document.getElementById("incomingMeta");
    if (banner && meta) {
      if (pending.length > 0 && isLocalHost) {
        const first = pending[0];
        meta.textContent = `${first.sender_device} wants to send "${first.filename}" (${formatBytes(first.file_size)})`;
        banner.dataset.transferId = first.transfer_id;
        banner.classList.remove("hidden");
      } else {
        banner.classList.add("hidden");
      }
    }

    const listEl = document.getElementById("pendingApprovalsList");
    if (listEl) {
      if (pending.length === 0) {
        listEl.className = "transfer-list empty-state";
        listEl.textContent = "No pending incoming file requests.";
      } else {
        listEl.className = "transfer-list";
        listEl.innerHTML = pending
          .map(
            (t) => `
          <div class="transfer-item-card">
            <div class="transfer-item-head">
              <div>
                <strong>${escapeHtml(t.filename)}</strong>
                <div class="file-meta">From ${escapeHtml(t.sender_device)} • ${formatBytes(t.file_size)}</div>
              </div>
              <div class="alert-actions">
                <button class="btn btn-success btn-sm" onclick="window.ShivShare.decideTransfer('${escapeHtml(t.transfer_id)}', true)">Accept</button>
                <button class="btn btn-danger btn-sm" onclick="window.ShivShare.decideTransfer('${escapeHtml(t.transfer_id)}', false)">Reject</button>
              </div>
            </div>
          </div>`
          )
          .join("");
      }
    }
  }

  async function decideTransfer(transferId, accept) {
    await apiFetch(`/api/transfers/${encodeURIComponent(transferId)}/decision`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ accept }),
    });
    await refreshActiveTransfers();
  }

  window.ShivShare.decideTransfer = decideTransfer;

  async function refreshActiveTransfers() {
    if (!isLocalHost && !state.approved) return;
    const { data } = await apiFetch("/api/transfers/active");
    if (data && data.ok) {
      state.transfers = data.transfers || [];
      renderIncomingApprovals();
      window.ShivShare.renderLiveTransfers?.(state.transfers);
    }
  }

  window.ShivShare.refreshActiveTransfers = refreshActiveTransfers;

  function renderDevicesSection() {
    const container = document.getElementById("devicesListContainer");
    const pinBox = document.getElementById("hostPinDisplay");
    if (pinBox && isLocalHost && state.status?.pairing_pin) {
      pinBox.innerHTML = `<span class="badge badge-info">Pairing PIN: <strong class="mono">${escapeHtml(state.status.pairing_pin)}</strong></span>`;
    }
    if (!container) return;

    if (!state.devices.length) {
      container.innerHTML = `<p class="muted">No devices registered yet.</p>`;
      return;
    }

    container.innerHTML = state.devices
      .map((d) => {
        const statusBadge =
          d.status === "approved" || d.status === "connected"
            ? '<span class="badge badge-success">Connected</span>'
            : d.status === "pending_approval"
            ? '<span class="badge badge-info">Pending Approval</span>'
            : `<span class="badge badge-danger">${escapeHtml(d.status)}</span>`;

        let actions = "";
        if (!d.is_host && isLocalHost) {
          if (d.status === "pending_approval") {
            actions += `<button class="btn btn-success btn-sm" onclick="window.ShivShare.deviceAction('${escapeHtml(d.device_id)}', 'approve')">Approve</button>`;
            actions += `<button class="btn btn-danger btn-sm" onclick="window.ShivShare.deviceAction('${escapeHtml(d.device_id)}', 'reject')">Reject</button>`;
          } else if (d.status === "approved") {
            actions += `<button class="btn btn-ghost btn-sm" onclick="window.ShivShare.deviceAction('${escapeHtml(d.device_id)}', 'disconnect')">Disconnect</button>`;
          }
        }

        return `
        <div class="device-card">
          <div class="transfer-item-head">
            <strong>${escapeHtml(d.name)}</strong>
            ${statusBadge}
          </div>
          <div class="file-meta">Type: ${escapeHtml(d.device_type || "Device")}</div>
          <div class="file-meta mono">IP: ${escapeHtml(d.ip)}</div>
          ${actions ? `<div class="alert-actions" style="margin-top:6px;">${actions}</div>` : ""}
        </div>`;
      })
      .join("");
  }

  async function deviceAction(deviceId, action) {
    await apiFetch(`/api/devices/${encodeURIComponent(deviceId)}/${action}`, { method: "POST" });
    await refreshStatusAndDevices();
  }

  window.ShivShare.deviceAction = deviceAction;

  async function loadHistorySection() {
    const search = document.getElementById("historySearchInput")?.value || "";
    const status = document.getElementById("historyStatusFilter")?.value || "all";
    const { data } = await apiFetch(
      `/api/history?status=${encodeURIComponent(status)}&search=${encodeURIComponent(search)}`
    );
    const tbody = document.getElementById("historyTableBody");
    if (!tbody) return;

    if (!data || !data.ok || !data.history?.length) {
      tbody.innerHTML = `<tr><td colspan="7" class="muted">No matching transfer history records.</td></tr>`;
      return;
    }

    tbody.innerHTML = data.history
      .map((row) => {
        const dt = row.created_at ? new Date(Number(row.created_at) * 1000).toLocaleString() : "-";
        const badgeCls =
          row.status === "completed" ? "badge-success" : row.status === "pending_approval" ? "badge-info" : "badge-danger";
        return `
        <tr>
          <td><strong>${escapeHtml(row.filename)}</strong></td>
          <td>${formatBytes(row.file_size)}</td>
          <td>${escapeHtml(row.sender_device)} → ${escapeHtml(row.receiver_device)}</td>
          <td><span class="badge ${badgeCls}">${escapeHtml(row.status)}</span></td>
          <td>${formatSpeed(row.avg_speed_bps)}</td>
          <td>${Number(row.duration_seconds || 0).toFixed(1)}s</td>
          <td>${escapeHtml(dt)}</td>
        </tr>`;
      })
      .join("");
  }

  async function loadSettingsSection() {
    const { data } = await apiFetch("/api/settings");
    if (!data || !data.ok) return;
    const s = data.settings || {};
    const nameInput = document.getElementById("settingDeviceName");
    const themeSel = document.getElementById("settingThemeSelect");
    if (nameInput) nameInput.value = s.device_name || "";
    if (themeSel) themeSel.value = s.theme || localStorage.getItem("shivshare_theme") || "dark";
  }

  function bindGlobalEvents() {
    const savedTheme = localStorage.getItem("shivshare_theme") || "dark";
    applyTheme(savedTheme);

    document.getElementById("themeToggleBtn")?.addEventListener("click", () => {
      const current = document.documentElement.getAttribute("data-theme") || "dark";
      const next = current === "dark" ? "light" : "dark";
      applyTheme(next);
      apiFetch("/api/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ theme: next }),
      }).catch(() => {});
    });

    document.getElementById("menuToggleBtn")?.addEventListener("click", () => {
      document.getElementById("sidebarNav")?.classList.toggle("open");
    });

    document.querySelectorAll("[data-section]").forEach((btn) => {
      btn.addEventListener("click", () => switchSection(btn.dataset.section));
    });

    document.querySelectorAll("[data-jump]").forEach((btn) => {
      btn.addEventListener("click", () => switchSection(btn.dataset.jump));
    });

    document.getElementById("acceptIncomingBtn")?.addEventListener("click", () => {
      const id = document.getElementById("incomingApprovalBox")?.dataset.transferId;
      if (id) decideTransfer(id, true);
    });

    document.getElementById("rejectIncomingBtn")?.addEventListener("click", () => {
      const id = document.getElementById("incomingApprovalBox")?.dataset.transferId;
      if (id) decideTransfer(id, false);
    });

    document.getElementById("pairForm")?.addEventListener("submit", async (e) => {
      e.preventDefault();
      const devName = document.getElementById("pairDeviceName")?.value || "";
      const pin = document.getElementById("pairPinInput")?.value || "";
      const fb = document.getElementById("pairFeedback");
      const { data } = await apiFetch("/api/pair/request", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          device_name: devName,
          pin,
          device_id: state.deviceId || undefined,
        }),
      });
      if (!data.ok) {
        if (fb) fb.textContent = data.error || "Pairing failed.";
        return;
      }
      state.sessionToken = data.session_token || "";
      state.deviceId = data.device?.device_id || "";
      sessionStorage.setItem("shivshare_session", state.sessionToken);
      sessionStorage.setItem("shivshare_device_id", state.deviceId);
      if (fb) fb.textContent = "PIN verified. Waiting for host approval...";
    });

    document.addEventListener("input", (e) => {
      if (e.target && e.target.id === "historySearchInput") loadHistorySection();
    });
    document.addEventListener("change", (e) => {
      if (e.target && e.target.id === "historyStatusFilter") loadHistorySection();
    });
    document.addEventListener("click", async (e) => {
      if (e.target && e.target.id === "clearHistoryBtn") {
        await apiFetch("/api/history", { method: "DELETE" });
        loadHistorySection();
      }
      if (e.target && e.target.id === "rotatePinBtn") {
        const { data } = await apiFetch("/api/settings", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ rotate_pin: true }),
        });
        const fb = document.getElementById("settingsFeedback");
        if (fb && data.ok) {
          fb.textContent = `New Pairing PIN: ${data.pairing_pin}`;
          refreshStatusAndDevices();
        }
      }
    });
    document.addEventListener("submit", async (e) => {
      if (e.target && e.target.id === "settingsForm") {
        e.preventDefault();
        const device_name = document.getElementById("settingDeviceName")?.value || "";
        const theme = document.getElementById("settingThemeSelect")?.value || "dark";
        applyTheme(theme);
        const { data } = await apiFetch("/api/settings", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ device_name, theme }),
        });
        const fb = document.getElementById("settingsFeedback");
        if (fb) fb.textContent = data.message || "Saved.";
        refreshStatusAndDevices();
      }
    });
  }

  function connectEventsStream() {
    try {
      const es = new EventSource("/api/events");
      es.onmessage = (ev) => {
        try {
          const msg = JSON.parse(ev.data);
          if (msg.type === "transfer_update") {
            refreshActiveTransfers();
            if (state.section === "history") loadHistorySection();
          } else if (msg.type === "device_update") {
            state.devices = msg.devices || state.devices;
            populateTargetDeviceSelect();
            if (!isLocalHost && state.deviceId) {
              const mine = state.devices.find((d) => d.device_id === state.deviceId);
              if (mine) {
                state.approved = mine.status === "approved";
                updatePairingGate();
              }
            }
            if (state.section === "devices") renderDevicesSection();
          }
        } catch (_) {}
      };
    } catch (_) {}

    // Fallback polling every 2 seconds for reliable status updates
    setInterval(() => {
      refreshActiveTransfers();
      refreshStatusAndDevices();
    }, 2000);
  }

  document.addEventListener("DOMContentLoaded", async () => {
    bindGlobalEvents();
    updatePairingGate();
    await refreshStatusAndDevices();
    await refreshActiveTransfers();
    connectEventsStream();
  });
})();