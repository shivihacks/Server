(function () {
  const { formatBytes, formatSpeed, formatEta, apiFetch, escapeHtml } = window.ShivShare;

  const sendState = {
    selectedFiles: [],
    activeItems: [], // { localId, transferId, file, name, size, transferred, speed, eta, status, error, thumbUrl, xhr }
  };

  function renderSelectedQueue() {
    const panel = document.getElementById("selectedFilesPreview");
    const list = document.getElementById("selectedFilesList");
    const summary = document.getElementById("selectedQueueSummary");
    if (!panel || !list || !summary) return;

    if (!sendState.selectedFiles.length) {
      panel.classList.add("hidden");
      list.innerHTML = "";
      return;
    }

    const totalSize = sendState.selectedFiles.reduce((acc, f) => acc + f.size, 0);
    summary.textContent = `${sendState.selectedFiles.length} file(s) selected (${formatBytes(totalSize)})`;
    list.innerHTML = sendState.selectedFiles
      .map((f) => `<li><span>${escapeHtml(f.name)}</span><span class="muted">${formatBytes(f.size)}</span></li>`)
      .join("");
    panel.classList.remove("hidden");
  }

  function computeOverallSendMetrics() {
    const totalBytes = sendState.activeItems.reduce((acc, it) => acc + it.size, 0);
    const doneBytes = sendState.activeItems.reduce((acc, it) => acc + Math.min(it.size, it.transferred), 0);
    const activeSpeed = sendState.activeItems
      .filter((it) => it.status === "transferring")
      .reduce((acc, it) => acc + (it.speed || 0), 0);
    const percent = totalBytes > 0 ? Math.min(100, (doneBytes / totalBytes) * 100) : 0;
    const remBytes = Math.max(0, totalBytes - doneBytes);
    const eta = activeSpeed > 1 ? remBytes / activeSpeed : null;
    return { totalBytes, doneBytes, activeSpeed, percent, eta };
  }

  function renderSendProgress() {
    const panel = document.getElementById("sendProgressPanel");
    const listEl = document.getElementById("individualTransfersList");
    if (!panel || !listEl) return;

    if (!sendState.activeItems.length) {
      panel.classList.add("hidden");
      return;
    }

    panel.classList.remove("hidden");
    const ov = computeOverallSendMetrics();

    document.getElementById("overallPercentBadge").textContent = `${ov.percent.toFixed(1)}%`;
    document.getElementById("overallProgressBar").style.width = `${ov.percent}%`;
    document.getElementById("overallBytesText").textContent = `${formatBytes(ov.doneBytes)} / ${formatBytes(ov.totalBytes)}`;
    document.getElementById("overallSpeedText").textContent = formatSpeed(ov.activeSpeed);
    document.getElementById("overallEtaText").textContent = formatEta(ov.eta);

    listEl.innerHTML = sendState.activeItems
      .map((it) => {
        const pct = it.size > 0 ? Math.min(100, (it.transferred / it.size) * 100) : it.status === "completed" ? 100 : 0;
        const badgeCls =
          it.status === "completed"
            ? "badge-success"
            : it.status === "failed" || it.status === "cancelled" || it.status === "rejected"
            ? "badge-danger"
            : "badge-info";

        const thumbHtml = it.thumbUrl
          ? `<img class="transfer-thumb" src="${escapeHtml(it.thumbUrl)}" alt="${escapeHtml(it.name)}" />`
          : "";

        const canCancel = it.status === "transferring" || it.status === "pending_approval" || it.status === "waiting";
        const cancelBtn = canCancel
          ? `<button class="btn btn-ghost btn-sm" onclick="window.ShivShare.cancelSendItem('${escapeHtml(it.localId)}')">Cancel</button>`
          : "";

        return `
        <div class="transfer-item-card">
          <div class="transfer-item-head">
            <div style="display:flex;align-items:center;gap:10px;">
              ${thumbHtml}
              <div>
                <div class="file-name">${escapeHtml(it.name)}</div>
                <div class="file-meta">${formatBytes(it.transferred)} / ${formatBytes(it.size)} • ${formatSpeed(it.speed)} • ETA ${formatEta(it.eta)}</div>
              </div>
            </div>
            <div style="display:flex;align-items:center;gap:6px;">
              <span class="badge ${badgeCls}">${escapeHtml(it.status.toUpperCase())}</span>
              ${cancelBtn}
            </div>
          </div>
          <div class="progress-track">
            <div class="progress-fill" style="width:${pct}%;"></div>
          </div>
          ${it.error ? `<div class="file-meta" style="color:var(--danger);margin-top:4px;">${escapeHtml(it.error)}</div>` : ""}
        </div>`;
      })
      .join("");
  }

  function uploadSingleItem(item) {
    return new Promise(async (resolve) => {
      if (item.cancelled) {
        item.status = "cancelled";
        renderSendProgress();
        return resolve();
      }

      const initRes = await apiFetch("/api/transfers/init", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          filename: item.name,
          file_size: item.size,
          auto_accept: document.body.dataset.localHost === "true",
        }),
      });

      if (!initRes.data || !initRes.data.ok) {
        item.status = "failed";
        item.error = initRes.data?.error || "Could not initialize transfer.";
        renderSendProgress();
        return resolve();
      }

      item.transferId = initRes.data.transfer.transfer_id;
      item.status = "transferring";
      renderSendProgress();

      const xhr = new XMLHttpRequest();
      item.xhr = xhr;
      const samples = [{ t: performance.now(), b: 0 }];
      let lastRender = 0;

      xhr.open("POST", `/api/transfers/${encodeURIComponent(item.transferId)}/upload`, true);
      if (window.ShivShare.csrfToken) {
        xhr.setRequestHeader("X-CSRF-Token", window.ShivShare.csrfToken);
      }
      if (window.ShivShare.state.sessionToken) {
        xhr.setRequestHeader("X-ShivShare-Session", window.ShivShare.state.sessionToken);
      }
      xhr.setRequestHeader("X-File-Size", String(item.size));

      xhr.upload.onprogress = (evt) => {
        if (!evt.lengthComputable) return;
        const now = performance.now();
        item.transferred = evt.loaded;
        samples.push({ t: now, b: evt.loaded });
        while (samples.length > 2 && now - samples[0].t > 3000) {
          samples.shift();
        }
        const dt = Math.max(0.15, (samples[samples.length - 1].t - samples[0].t) / 1000);
        const db = samples[samples.length - 1].b - samples[0].b;
        item.speed = db / dt;
        const rem = Math.max(0, item.size - evt.loaded);
        item.eta = item.speed > 1 ? rem / item.speed : null;

        if (now - lastRender > 200) {
          lastRender = now;
          renderSendProgress();
        }
      };

      xhr.onload = () => {
        item.xhr = null;
        if (xhr.status >= 200 && xhr.status < 300) {
          item.transferred = item.size;
          item.speed = 0;
          item.eta = 0;
          item.status = "completed";
        } else {
          let errMsg = "Upload failed.";
          try {
            const parsed = JSON.parse(xhr.responseText);
            if (parsed.error) errMsg = parsed.error;
          } catch (_) {}
          item.status = item.cancelled ? "cancelled" : "failed";
          item.error = errMsg;
        }
        renderSendProgress();
        window.ShivShare.refreshActiveTransfers?.();
        resolve();
      };

      xhr.onerror = () => {
        item.xhr = null;
        item.status = item.cancelled ? "cancelled" : "failed";
        item.error = "Network connection interrupted during transfer.";
        renderSendProgress();
        window.ShivShare.refreshActiveTransfers?.();
        resolve();
      };

      xhr.onabort = () => {
        item.xhr = null;
        item.status = "cancelled";
        item.error = "Transfer cancelled.";
        renderSendProgress();
        resolve();
      };

      // Stream file directly via XHR body without reading whole file into memory
      xhr.send(item.file);
    });
  }

  async function startBatchUpload() {
    if (!sendState.selectedFiles.length) return;

    sendState.activeItems = sendState.selectedFiles.map((file, idx) => {
      const isImg = /^image\//i.test(file.type) && file.size <= 15 * 1024 * 1024;
      return {
        localId: `local_${Date.now()}_${idx}`,
        transferId: null,
        file,
        name: file.name,
        size: file.size,
        transferred: 0,
        speed: 0,
        eta: null,
        status: "waiting",
        error: null,
        thumbUrl: isImg ? URL.createObjectURL(file) : null,
        xhr: null,
        cancelled: false,
      };
    });

    sendState.selectedFiles = [];
    document.getElementById("sendFileInput").value = "";
    renderSelectedQueue();
    renderSendProgress();

    for (const item of sendState.activeItems) {
      await uploadSingleItem(item);
    }
  }

  async function cancelSendItem(localId) {
    const item = sendState.activeItems.find((i) => i.localId === localId);
    if (!item) return;
    item.cancelled = true;
    if (item.xhr) {
      item.xhr.abort();
    }
    if (item.transferId) {
      await apiFetch(`/api/transfers/${encodeURIComponent(item.transferId)}/cancel`, { method: "POST" }).catch(() => {});
    }
    item.status = "cancelled";
    renderSendProgress();
  }

  window.ShivShare.cancelSendItem = cancelSendItem;

  function renderLiveTransfers(transfers) {
    const homeEl = document.getElementById("homeLiveTransfers");
    const recEl = document.getElementById("receiveLiveList");
    const activeCountEl = document.getElementById("homeActiveTransfers");

    const active = (transfers || []).filter((t) => t.status === "transferring" || t.status === "pending_approval");
    if (activeCountEl) activeCountEl.textContent = String(active.length);

    const recent = (transfers || []).slice(0, 6);
    const html = recent.length
      ? recent
          .map(
            (t) => `
        <div class="transfer-item-card">
          <div class="transfer-item-head">
            <div>
              <strong>${escapeHtml(t.filename)}</strong>
              <div class="file-meta">${escapeHtml(t.sender_device)} → ${escapeHtml(t.receiver_device)} • ${formatBytes(t.transferred_bytes)} / ${formatBytes(t.file_size)} • ${formatSpeed(t.speed_bps)} • ETA ${formatEta(t.eta_seconds)}</div>
            </div>
            <span class="badge ${t.status === "completed" ? "badge-success" : "badge-info"}">${escapeHtml(t.status)}</span>
          </div>
          <div class="progress-track">
            <div class="progress-fill" style="width:${Number(t.percent || 0)}%;"></div>
          </div>
        </div>`
          )
          .join("")
      : null;

    if (homeEl) {
      homeEl.className = html ? "transfer-list" : "transfer-list empty-state";
      homeEl.innerHTML = html || "No active transfers right now.";
    }
    if (recEl) {
      const incoming = (transfers || []).filter((t) => t.direction === "upload" && t.status !== "pending_approval").slice(0, 8);
      if (!incoming.length) {
        recEl.className = "transfer-list empty-state";
        recEl.textContent = "No incoming transfers in progress.";
      } else {
        recEl.className = "transfer-list";
        recEl.innerHTML = incoming
          .map(
            (t) => `
          <div class="transfer-item-card">
            <div class="transfer-item-head">
              <div>
                <strong>${escapeHtml(t.filename)}</strong>
                <div class="file-meta">${formatBytes(t.transferred_bytes)} / ${formatBytes(t.file_size)} • ${formatSpeed(t.speed_bps)} • ETA ${formatEta(t.eta_seconds)}</div>
              </div>
              <span class="badge ${t.status === "completed" ? "badge-success" : "badge-info"}">${escapeHtml(t.status)}</span>
            </div>
            <div class="progress-track">
              <div class="progress-fill" style="width:${Number(t.percent || 0)}%;"></div>
            </div>
          </div>`
          )
          .join("");
      }
    }
  }

  window.ShivShare.renderLiveTransfers = renderLiveTransfers;

  document.addEventListener("DOMContentLoaded", () => {
    const fileInput = document.getElementById("sendFileInput");
    fileInput?.addEventListener("change", () => {
      const picked = Array.from(fileInput.files || []);
      if (picked.length) {
        sendState.selectedFiles = sendState.selectedFiles.concat(picked);
        renderSelectedQueue();
      }
    });

    document.getElementById("clearSelectedFilesBtn")?.addEventListener("click", () => {
      sendState.selectedFiles = [];
      if (fileInput) fileInput.value = "";
      renderSelectedQueue();
    });

    document.getElementById("startSendBtn")?.addEventListener("click", startBatchUpload);
  });
})();